# my-website
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>流浪動物森林之家｜每一個生命，都值得一個家</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300;400;500;700;900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="style.css">
</head>

<body>

<!-- 導覽列 -->
<header>
    <div class="container">
        <h2 class="logo">🐾 流浪動物森林之家</h2>

        <nav>
            <a href="#about">關於我們</a>
            <a href="#story">救援故事</a>
            <a href="#adopt">我要認養</a>
            <a href="#donate">愛心捐款</a>
            <a href="#contact">聯絡我們</a>
        </nav>
    </div>
</header>

<!-- Hero -->
<section class="hero">

<div class="hero-content">

<h1>每一個生命，都值得一個家</h1>

<p>
陪伴流浪毛孩找到幸福的歸屬
</p>

<a href="#donate" class="btn">立即支持</a>

</div>

</section>

<!-- 關於 -->
<section id="about" class="section">

<h2>我們的理念</h2>

<p>
流浪動物森林之家致力於救援、醫療、安置及送養流浪犬貓，
相信每一條生命都值得被溫柔對待，
透過大家的力量，讓更多毛孩重新找到幸福。
</p>

</section>

<!-- 數據 -->
<section class="stats">

<div class="card">
<h3>3,000+</h3>
<p>成功救援</p>
</div>

<div class="card">
<h3>2,500+</h3>
<p>成功送養</p>
</div>

<div class="card">
<h3>500+</h3>
<p>志工夥伴</p>
</div>

</section>

<!-- 救援故事 -->

<section id="story" class="section">

<h2>救援故事</h2>

<div class="cards">

<div class="story-card">
<img src="images/dog1.jpg">
<h3>午吉</h3>
<p>從受傷浪浪到幸福家庭。</p>
</div>

<div class="story-card">
<img src="images/dog2.jpg">
<h3>奶茶</h3>
<p>等待屬於自己的家。</p>
</div>

<div class="story-card">
<img src="images/cat1.jpg">
<h3>小虎</h3>
<p>經過治療重新展開新生活。</p>
</div>

</div>

</section>

<!-- 認養 -->

<section id="adopt" class="section">

<h2>等待認養</h2>

<p>
給毛孩一個溫暖的家，
也讓自己多一位家人。
</p>

<a class="btn" href="#">我要認養</a>

</section>

<!-- 捐款 -->

<section id="donate" class="donate">

<h2>支持我們</h2>

<p>
您的每一份捐款，
都是毛孩活下去的希望。
</p>

<a class="btn">立即捐款</a>

</section>

<!-- 聯絡 -->

<section id="contact" class="section">

<h2>聯絡我們</h2>

<p>Email：service@example.com</p>

<p>Facebook：流浪動物森林之家</p>

<p>LINE：@foresthome</p>

</section>

<footer>

<p>
© 2026 流浪動物森林之家 All Rights Reserved.
</p>

</footer>

<script src="script.js"></script>

</body>
</html>
